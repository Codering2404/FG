/**
 * focusguard-bridge.js
 * 
 * Drop this script into the HTML frontend (index.html).
 * It detects whether the app is running inside an Android WebView
 * and wires all the UI actions to the native Android.* bridge.
 * When running in a browser (development), it falls back to the
 * localStorage mock so the HTML still works standalone.
 */

const IS_ANDROID = typeof Android !== 'undefined';

// ─── State received from Android on page load ────────────────────────────────

window.onAndroidState = function(state) {
  console.log("Received state:", state);

  // 1. Handle Setup / Onboarding View if it exists
  const statusEl = document.getElementById('status');
  if (statusEl) {
    if (state.usagePermission && state.accessibilityEnabled) {
        statusEl.innerText = "All systems go!";
        statusEl.style.color = "green";
        if (window.Android) Android.completeOnboarding();
        if (window.showView) showView('main-view');
    } else {
        let msg = "Permissions required:";
        if (!state.usagePermission) msg += "\n• Usage Access";
        if (!state.accessibilityEnabled) msg += "\n• Accessibility Service";
        statusEl.innerText = msg;
        statusEl.style.color = "orange";
        if (window.showView) showView('setup-view');
    }
  }

  // 2. Safely update Dashboard elements if they exist
  if (state.lang && typeof curLang !== 'undefined' && state.lang !== curLang) {
    if (window.setLang) setLang(state.lang);
  }

  const sw  = document.getElementById('focus-sw');
  const tg  = document.getElementById('focus-toggle');
  const sub = document.getElementById('focus-sub');
  const lbl = document.getElementById('shield-label');

  if (sw && tg && sub && lbl) {
    const T = (typeof LANGS !== 'undefined') ? (LANGS[curLang] || LANGS.en) : {};
    if (state.protectionOn) {
      sw.classList.add('on'); tg.classList.add('active');
      sub.textContent = T.features_blocked || 'features blocked';
      lbl.textContent = T.active || 'active';
    } else {
      sw.classList.remove('on'); tg.classList.remove('active');
      sub.textContent = 'protection paused';
      lbl.textContent = 'paused';
    }
  }

  // Screen time
  if (state.screenTimeMin != null) {
    const h = Math.floor(state.screenTimeMin / 60);
    const m = state.screenTimeMin % 60;
    const timeEl = document.querySelector('.home-time');
    if (timeEl) timeEl.textContent = h > 0 ? `${h}h ${m}m` : `${m}m`;
  }

  // Permission banner (fallback)
  if (!state.usagePermission || !state.accessibilityEnabled) {
    if (typeof showPermissionBanner === 'function') {
        showPermissionBanner(!state.usagePermission, !state.accessibilityEnabled);
    }
  }

  // Sync toggle states
  if (state.blockRules && Array.isArray(state.blockRules)) {
    if (typeof syncToggleStates === 'function') syncToggleStates(state.blockRules);
  }
};

// ─── Language change ─────────────────────────────────────────────────────────

const _origSetLang = window.setLang;
window.setLang = function(l) {
  _origSetLang(l);
  if (IS_ANDROID) Android.setLanguage(l);
};

// ─── Protection toggle — requires PIN → then calls Android ───────────────────

window.toggleFocus = function() {
  if (strictMode) { alert('Strict mode active.'); return; }
  openPinModal('focus');
};

// Override handlePinSuccess to call Android after PIN
const _origHandlePinSuccess = window.handlePinSuccess;
window.handlePinSuccess = function() {
  if (curPinAction === 'focus') {
    const nowOn = !document.getElementById('focus-sw').classList.contains('on');
    if (IS_ANDROID) {
      Android.verifyPin(pinBuffer, 'window._nativePinCallback');
      // _nativePinCallback is set below
      window._nativePinCallback = function(ok) {
        if (ok) Android.setProtection(nowOn);
      };
    }
  } else if (curPinAction === 'toggle_off') {
    // User wants to disable a block rule — show ad gate first
    if (IS_ANDROID) {
      Android.showAdGate(
        'Disabling a block requires watching ads',
        'window._adGateComplete'
      );
      window._adGateComplete = function() {
        if (pendingToggleEl) {
          pendingToggleEl.classList.remove('on');
          // Persist: extract rule ID from data attribute
          const ruleId = pendingToggleEl.dataset.ruleId;
          if (ruleId && IS_ANDROID) Android.setRuleEnabled(parseInt(ruleId), false);
          pendingToggleEl = null;
        }
      };
    }
  }
  if (_origHandlePinSuccess) _origHandlePinSuccess();
};

// ─── Block rule toggles → Android ────────────────────────────────────────────

window.requirePinToggle = function(el) {
  if (el.classList.contains('on')) {
    pendingToggleEl = el;
    openPinModal('toggle_off');
  } else {
    // Turning ON requires no PIN — just save
    el.classList.add('on');
    const pkg     = el.dataset.package;
    const feature = el.dataset.feature;
    const label   = el.dataset.label;
    if (IS_ANDROID && pkg && feature) {
      Android.saveBlockRule(pkg, feature, label || feature, true);
    }
  }
};

// ─── Schedule toggles → Android ──────────────────────────────────────────────

window.toggleSched = function(el) {
  el.classList.toggle('active-sched');
  const badge = el.querySelector('.sched-badge');
  const T = LANGS[curLang] || LANGS.en;
  const isNowActive = el.classList.contains('active-sched');
  if (isNowActive) { badge.classList.add('running'); badge.textContent = T.running || 'running'; }
  else             { badge.classList.remove('running'); badge.textContent = T.waiting || 'waiting'; }

  const scheduleId = el.dataset.scheduleId;
  if (IS_ANDROID && scheduleId) {
    Android.setRuleEnabled(parseInt(scheduleId), isNowActive); // reuses same API
  }
};

// ─── Strict mode → Android ───────────────────────────────────────────────────

window.toggleStrict = function() {
  if (strictMode) return;
  const msg = curLang === 'es'
    ? '¿Activar modo estricto por cuántas horas?'
    : 'Activate strict mode for how many hours? (enter a number)';
  const hours = parseInt(prompt(msg) || '0');
  if (!hours || hours <= 0) return;
  if (IS_ANDROID) Android.activateStrictMode(hours);
  strictMode = true;
  document.getElementById('strict-status').textContent =
    (LANGS[curLang] || LANGS.en).active || 'active';
  document.getElementById('strict-status').className = 'sec-status on';
};

// ─── Onboarding complete → Android ───────────────────────────────────────────

const _origStartApp = window.startApp;
window.startApp = function() {
  if (IS_ANDROID) Android.completeOnboarding();
  _origStartApp();
};

// ─── Permission banner ────────────────────────────────────────────────────────

function showPermissionBanner(needsUsage, needsAccessibility) {
  const existing = document.getElementById('perm-banner');
  if (existing) return;

  const banner = document.createElement('div');
  banner.id = 'perm-banner';
  banner.style.cssText = `
    position:fixed;bottom:0;left:0;right:0;
    background:#1a1a1a;border-top:1px solid #2d2d2d;
    padding:14px 18px;z-index:999;font-family:'DM Mono',monospace;
    font-size:11px;color:#ffb84d;
  `;

  let msg = '⚠ Permissions needed: ';
  const actions = [];
  if (needsUsage)       actions.push('<button onclick="Android.openUsageSettings()" style="background:none;border:1px solid #ffb84d;color:#ffb84d;padding:4px 10px;border-radius:4px;font-family:monospace;cursor:pointer;margin-left:8px">Usage Access →</button>');
  if (needsAccessibility) actions.push('<button onclick="Android.openAccessibilitySettings()" style="background:none;border:1px solid #ffb84d;color:#ffb84d;padding:4px 10px;border-radius:4px;font-family:monospace;cursor:pointer;margin-left:8px">Accessibility →</button>');

  banner.innerHTML = msg + actions.join('');
  document.body.appendChild(banner);
}

// ─── Sync toggle visual states from persisted rules ──────────────────────────

function syncToggleStates(rules) {
  // For each toggle that has data-feature + data-package attributes,
  // set its ON state from the rules array
  document.querySelectorAll('.toggle-sm[data-feature]').forEach(toggle => {
    const pkg     = toggle.dataset.package;
    const feature = toggle.dataset.feature;
    const rule = rules.find(r => r.packageName === pkg && r.featureKey === feature);
    if (rule) {
      toggle.classList.toggle('on', rule.isEnabled);
    }
  });
}
