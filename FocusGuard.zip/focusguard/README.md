# FocusGuard — Android App

Full-featured digital wellbeing app with in-app feature blocking,
accountability partner system, PIN protection, anti-uninstall, and AdMob integration.

---

## Project structure

```
focusguard/
├── app/src/main/
│   ├── AndroidManifest.xml          # All permissions & components
│   ├── java/com/focusguard/app/
│   │   ├── FocusGuardApp.kt         # Application class (AdMob + Firebase init)
│   │   ├── data/
│   │   │   ├── FocusDatabase.kt     # Room DB: BlockRule, Schedule, UsageLog
│   │   │   └── PreferencesManager.kt# DataStore: PIN hash, strict mode, language
│   │   ├── services/
│   │   │   ├── AppMonitorService.kt # Foreground service — polls foreground app every 500ms
│   │   │   └── FocusAccessibilityService.kt  # Detects Reels/Shorts/FYP in-app
│   │   ├── ui/
│   │   │   ├── MainActivity.kt      # WebView loading the HTML frontend
│   │   │   ├── BlockedActivity.kt   # Overlay with 5s cooldown + banner ad
│   │   │   └── PinDialogFragment.kt # PIN entry + AdGateFragment (15 min ads)
│   │   ├── receivers/
│   │   │   └── Receivers.kt         # DeviceAdmin + BootReceiver + PartnerNotifier
│   │   └── utils/
│   │       └── ScheduleEvaluator.kt # Time-window logic for schedules
│   └── res/xml/
│       ├── accessibility_service_config.xml
│       └── device_admin_config.xml
├── functions/
│   └── index.js                     # Firebase Cloud Functions (partner notifications)
├── build.gradle
└── settings.gradle
```

---

## How the blocking works

### App-level blocking (AppMonitorService)
1. `UsageStatsManager` is queried every 500 ms.
2. The app with the most-recent `lastTimeUsed` is considered foreground.
3. If it matches an enabled `BlockRule` AND the current time falls within an
   active `Schedule`, `BlockedActivity` is launched on top.

### In-app feature blocking (FocusAccessibilityService)
1. Listens for `TYPE_WINDOW_STATE_CHANGED` and `TYPE_WINDOW_CONTENT_CHANGED`.
2. For each supported app, traverses the accessibility node tree to detect
   known UI identifiers (resource-IDs, content-descriptions).
3. If a blocked feature is detected, `BlockedActivity` is launched.

| App       | Blocked feature | Detection method                          |
|-----------|-----------------|-------------------------------------------|
| Instagram | Reels           | `view_id = clips_tab` selected            |
| Instagram | Explore         | `view_id = explore_tab`                   |
| YouTube   | Shorts          | Bottom-nav item description = "Shorts"    |
| TikTok    | For You         | Tab description "For You" selected        |
| TikTok    | Following       | Tab description "Following" selected      |
| X/Twitter | For You feed    | Tab description "For you" selected        |
| Facebook  | Reels           | Node description contains "Reels"         |

> **Note:** App UI updates may change resource IDs. Review after major app updates.

---

## Permissions required (and why)

| Permission                    | Why                                               | How granted            |
|-------------------------------|---------------------------------------------------|------------------------|
| `PACKAGE_USAGE_STATS`         | Read which app is in foreground                   | Settings > Special access |
| Accessibility Service         | Detect in-app features (Reels, Shorts, etc.)      | Settings > Accessibility  |
| `SYSTEM_ALERT_WINDOW`         | Draw BlockedActivity overlay                      | Settings > Special access |
| Device Administrator          | Prevent uninstall without consent                 | In-app dialog             |
| `FOREGROUND_SERVICE`          | Keep monitoring service alive                     | Auto-granted              |
| `POST_NOTIFICATIONS`          | Block alerts (Android 13+)                        | Runtime dialog             |
| `RECEIVE_BOOT_COMPLETED`      | Restart service after reboot                      | Auto-granted              |

---

## Setup steps

### 1. Firebase
```bash
# Install Firebase CLI
npm install -g firebase-tools
firebase login
firebase init           # select Functions + Messaging
firebase deploy --only functions
```
- Download `google-services.json` from Firebase console
- Place it at `app/google-services.json`

### 2. AdMob
- Create an AdMob account at admob.google.com
- Create a new Android app
- Create two ad units: one Banner, one Rewarded
- Replace the placeholder IDs in:
  - `AndroidManifest.xml`: `com.google.android.gms.ads.APPLICATION_ID`
  - `BlockedActivity.kt`: `AD_UNIT_BANNER`
  - `PinDialogFragment.kt`: `AD_UNIT_REWARDED`

### 3. Build & sign
```bash
# Generate a keystore (keep this file SAFE — you need it for every update)
keytool -genkey -v -keystore focusguard-release.jks \
        -alias focusguard -keyalg RSA -keysize 2048 -validity 10000

# Set environment variables
export KEYSTORE_PATH=/path/to/focusguard-release.jks
export KEYSTORE_PASS=your_store_password
export KEY_ALIAS=focusguard
export KEY_PASS=your_key_password

# Build release APK / AAB
./gradlew bundleRelease        # produces .aab for Play Store (recommended)
./gradlew assembleRelease      # produces .apk
```

---

## Play Store publishing checklist

### Google Play Console setup
1. Go to play.google.com/console → Create app
2. Select: App type = App, Free/Paid, Category = Health & Fitness
3. Fill in store listing (title, short description, full description, screenshots)

### Required screenshots
- 2+ phone screenshots (1080×1920 px minimum)
- 1 feature graphic (1024×500 px)

### Content rating
- Complete the questionnaire
- For an app that blocks adult content: answer honestly about content filtering

### Privacy policy (REQUIRED)
- Host a privacy policy at a public URL
- Must disclose: Accessibility Service usage, UsageStats usage, what data is sent to Firebase
- Template: https://www.privacypolicygenerator.info

### Sensitive permissions declarations
Play Store requires you to declare use of:
- **Accessibility Service** → Declare in Play Console > App content > Sensitive permissions
  - Justification: "Used to detect navigation to blocked in-app features (e.g. Instagram Reels) to enforce user-configured content restrictions."
- **PACKAGE_USAGE_STATS** → Declare similarly
  - Justification: "Used to detect which app is in the foreground to enforce app-level blocks."

### Upload
```bash
# Upload the .aab file in Play Console:
# Release > Production > Create new release > Upload
```

### Review timeline
- First submission: 3–7 days
- Subsequent updates: 1–3 days
- Apps with Accessibility Service declarations receive extra review scrutiny — be precise in your justifications.

---

## Architecture diagram

```
┌─────────────────────────────────────────────────────────┐
│                     Android Device                       │
│                                                          │
│  ┌──────────────┐    ┌──────────────────────────────┐   │
│  │   WebView    │    │    AppMonitorService          │   │
│  │  (HTML/CSS/  │    │  (foreground, always running) │   │
│  │   JS UI)     │    │  polls UsageStatsManager      │   │
│  └──────┬───────┘    │  every 500ms                  │   │
│         │ JS Bridge  └──────────────┬────────────────┘   │
│         ▼                           │ match found         │
│  ┌──────────────┐    ┌──────────────▼────────────────┐   │
│  │ MainActivity │    │  FocusAccessibilityService    │   │
│  │              │    │  listens for in-app navigation│   │
│  └──────────────┘    └──────────────┬────────────────┘   │
│                                     │ block triggered     │
│                      ┌──────────────▼────────────────┐   │
│                      │       BlockedActivity         │   │
│                      │  5s cooldown + banner ad      │   │
│                      │  PIN unlock → AdGate (15min)  │   │
│                      └──────────────┬────────────────┘   │
│                                     │ PIN fail x3         │
└─────────────────────────────────────┼─────────────────────┘
                                      │ FCM push
                              ┌───────▼────────┐
                              │ Firebase Cloud  │
                              │ Function        │
                              │ notifyPartner() │
                              └───────┬─────────┘
                                      │ FCM
                              ┌───────▼─────────┐
                              │ Partner's phone  │
                              │ (push notification)│
                              └──────────────────┘
```

---

## Local Room DB schema

```sql
CREATE TABLE block_rules (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    packageName TEXT NOT NULL,
    featureKey  TEXT NOT NULL,   -- "reels" | "shorts" | "fyp" | ...
    featureLabel TEXT NOT NULL,
    isEnabled   INTEGER DEFAULT 1,
    createdAt   INTEGER
);

CREATE TABLE schedules (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    name        TEXT NOT NULL,
    startHour   INTEGER, startMin INTEGER,
    endHour     INTEGER, endMin   INTEGER,
    daysOfWeek  TEXT,    -- "1,2,3,4,5"
    isEnabled   INTEGER DEFAULT 1,
    wifiSsid    TEXT,
    locationLabel TEXT
);

CREATE TABLE usage_logs (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    packageName     TEXT,
    date            TEXT,   -- "2024-03-15"
    totalMinutes    INTEGER DEFAULT 0,
    blockedAttempts INTEGER DEFAULT 0
);
```
